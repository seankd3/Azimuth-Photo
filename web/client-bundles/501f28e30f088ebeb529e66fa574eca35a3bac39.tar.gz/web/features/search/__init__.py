"""Search route package."""
