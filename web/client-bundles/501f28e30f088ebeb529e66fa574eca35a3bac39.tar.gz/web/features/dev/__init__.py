"""Local diagnostic route package."""
