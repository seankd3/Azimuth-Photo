"""Local controls for the satellite sync worker."""

import asyncio

import db

from fastapi import APIRouter, Query, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

from core.version import API_REV, app_version
from features.sync import contract, freeup, oplog, satellite
from features.sync.sync_worker import get_worker
from features.trash import service as trash_service


router = APIRouter(tags=["sync"])
_manual_sync_tasks: set[asyncio.Task] = set()


class FreeUpRequest(BaseModel):
    older_than_days: int = Field(default=30, ge=0, le=36500)


class FreeUpCancelRequest(BaseModel):
    pass


def _start_manual_sync_task(coro) -> None:
    task = asyncio.create_task(coro)
    _manual_sync_tasks.add(task)
    task.add_done_callback(_manual_sync_tasks.discard)


async def _refresh_mirror(worker) -> None:
    try:
        await worker.mirror.refresh()
    except Exception as error:
        worker.mirror._status["last_error"] = str(error)


async def _prefetch_browse_tier(worker) -> None:
    try:
        await worker.prefetch.prefetch_once(size="sm")
    except Exception as error:
        worker.prefetch._status["last_error"] = str(error)


@router.post("/api/sync/hub")
async def attach_hub(request: Request):
    """Runtime standalone → satellite upgrade: store the hub and start syncing."""

    if not satellite.is_satellite_mode():
        return JSONResponse({"error": "A hub cannot attach to another hub"}, status_code=400)
    body = await request.json()
    try:
        result = await satellite.attach_hub(
            str(body.get("url") or ""), str(body.get("device_token") or "")
        )
    except ValueError as error:
        return JSONResponse({"error": str(error)}, status_code=400)
    return result


@router.get("/api/sync/status")
async def sync_status(lr_exports_since: float = 0.0):
    worker = get_worker()
    if not satellite.is_satellite_mode() or worker is None:
        hub_state = (
            contract.hub_status(satellite.hub_url())
            if satellite.has_hub()
            else {"hub_health": "ok", "api_rev": API_REV, "app_version": app_version()}
        )
        status = {"mode": "satellite" if satellite.is_satellite_mode() else "hub", "paused": False, "queue_depth": 0, "bytes_remaining": 0, "throughput_bps": 0, "current_file": None, "recent_errors": [], "mirror": {"cursor": 0, "rows_applied": 0, "skipped_unhashed": 0, "last_refresh_at": None}, "prefetch": {"state": "idle", "cached": 0, "total": 0}, **hub_state}
    else:
        status = worker.status()
    pending = (
        await trash_service.pending_hub_trash_refs(db.DB_PATH)
        if satellite.is_satellite_mode()
        else {"count": 0}
    )
    status["pending_hub_trash"] = int(pending["count"])
    status["pending_ops"] = await oplog.pending_entry_count(db.DB_PATH)
    # Quiet LR bridge signals — piggyback; no dedicated poll loop.
    from features.sync import lr_status

    status["lr"] = await lr_status.bridge_status_payload(
        db.DB_PATH,
        exports_since=lr_exports_since,
    )
    return status


@router.post("/api/sync/pause")
async def sync_pause():
    worker = get_worker()
    if worker is not None:
        worker.pause()
    return await sync_status()


@router.post("/api/sync/resume")
async def sync_resume():
    worker = get_worker()
    if worker is not None:
        worker.resume()
    return await sync_status()


@router.post("/api/sync/now")
async def sync_now():
    worker = get_worker()
    if worker is not None:
        worker.sync_now()
    return await sync_status()


@router.get("/api/sync/freeable")
async def sync_freeable(
    older_than_days: int = Query(default=30, ge=0, le=36500),
):
    if not satellite.has_hub():
        return JSONResponse(
            {"error": "A connected satellite is required to free local originals"},
            status_code=400,
        )
    try:
        return await freeup.freeable(db.DB_PATH, older_than_days)
    except RuntimeError as error:
        return JSONResponse({"error": str(error)}, status_code=503)


@router.post("/api/sync/freeup")
async def sync_freeup(body: FreeUpRequest):
    if not satellite.has_hub():
        return JSONResponse(
            {"error": "A connected satellite is required to free local originals"},
            status_code=400,
        )
    job = freeup.start_job(db.DB_PATH, body.older_than_days)
    return JSONResponse(job.status(), status_code=202, headers={"Retry-After": "1"})


@router.get("/api/sync/freeup/{job_id}")
async def sync_freeup_status(job_id: str):
    job = freeup.job_for_id(job_id)
    if job is None:
        return JSONResponse({"error": "Free up space job not found"}, status_code=404)
    return job.status()


@router.post("/api/sync/freeup/{job_id}/cancel")
async def sync_freeup_cancel(job_id: str, _body: FreeUpCancelRequest):
    job = freeup.job_for_id(job_id)
    if job is None:
        return JSONResponse({"error": "Free up space job not found"}, status_code=404)
    freeup.request_cancel(job)
    return job.status()


@router.post("/api/sync/mirror/refresh")
async def sync_mirror_refresh():
    worker = get_worker()
    if worker is not None:
        _start_manual_sync_task(_refresh_mirror(worker))
    return JSONResponse(
        {"status": "pending", "job": "mirror_refresh"},
        status_code=202,
        headers={"Retry-After": "1"},
    )


@router.post("/api/sync/prefetch")
async def sync_prefetch():
    worker = get_worker()
    if worker is not None:
        _start_manual_sync_task(_prefetch_browse_tier(worker))
    return JSONResponse(
        {"status": "pending", "job": "thumb_prefetch"},
        status_code=202,
        headers={"Retry-After": "1"},
    )


@router.post("/api/sync/prefetch/loupe/{image_id}")
async def sync_prefetch_loupe(image_id: int):
    worker = get_worker()
    if worker is not None:
        await worker.prefetch.enqueue_loupe_neighbors(image_id)
    return await sync_status()


@router.post("/api/sync/prefetch/develop/{image_id}")
async def sync_prefetch_develop(image_id: int):
    worker = get_worker()
    if worker is not None:
        await worker.prefetch.enqueue_develop_siblings(image_id)
    return await sync_status()
