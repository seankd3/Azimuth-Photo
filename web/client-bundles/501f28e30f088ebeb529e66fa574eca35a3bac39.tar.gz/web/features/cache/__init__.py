"""Cache route package."""
