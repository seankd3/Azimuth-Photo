import { createCollection, getRankings, previewThumbUrl, removeFromCollection } from './api.js';
import { emit, on, scopeParams, selection, selectionChanged, setImages, setRankingsMeta, viewState } from './state.js';
import { loadScopePage } from './scope_data.js';
import { releaseFocus, trapFocus } from './focusTrap.js';
import { showToast } from './toast.js';
import { icon } from '../icons.js';
import { toggleSelection } from './selection.js';
import { createPendingPreviewPoll, pendingPreviewCount } from '../previews.js';
import { photoAspect as aspect } from './dom.js';

const GAP_KEY = 'pa_d_event_gap';
const PAGE_SIZE = 100;
const SORTED_SIGNAL_MIN = 3;
let mounted = false;
let initialized = false;
let offset = 0;
let done = false;
let loading = false;
let generation = 0;
let gapHours = Number(localStorage.getItem(GAP_KEY) || 6);
let images = [];
let groups = [];
const imageIndexes = new Map();
let observer = null;
let imageObserver = null;
let menu = null;
let savedScrollTop = 0;
const expandedEvents = new Set();
const thumbnailPoll = createPendingPreviewPoll({
    active: () => mounted,
    pending: () => pendingPreviewCount(images),
    refresh: refreshPendingPreviews,
});
const { schedule: scheduleThumbnailPoll, stop: stopThumbnailPoll } = thumbnailPoll;

const esc = (value) => String(value == null ? '' : value).replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
}[c]));
const fmt = (n) => Number(n || 0).toLocaleString('en-US');

function captureMs(img) {
    const raw = img.date_taken || img.file_modified_at || img.created_at || '';
    const parsed = raw ? Date.parse(raw) : Number.NaN;
    return Number.isFinite(parsed) ? parsed : null;
}

function titleFor(group) {
    const first = new Date(group.start);
    const last = new Date(group.end);
    const sameDay = first.toDateString() === last.toDateString();
    const opts = { month: 'short', day: 'numeric', year: 'numeric' };
    if (sameDay) return first.toLocaleDateString(undefined, opts);
    return `${first.toLocaleDateString(undefined, opts)} - ${last.toLocaleDateString(undefined, opts)}`;
}

function signals(img) {
    return (Number(img.comparisons) || 0) + (Number(img.propagated_updates) || 0);
}

function groupImages(sourceImages) {
    const dated = sourceImages
        .map((img, index) => ({ img, index, ms: captureMs(img) }))
        .filter((item) => item.ms != null)
        .sort((a, b) => b.ms - a.ms);
    const gapMs = gapHours * 3600 * 1000;
    const result = [];
    for (const item of dated) {
        const last = result[result.length - 1];
        if (!last || Math.abs(last.lastMs - item.ms) > gapMs) {
            result.push({
                id: `ev-${item.ms}`,
                start: item.ms,
                end: item.ms,
                lastMs: item.ms,
                images: [item.img],
            });
        } else {
            last.images.push(item.img);
            last.end = Math.min(last.end, item.ms);
            last.start = Math.max(last.start, item.ms);
            last.lastMs = item.ms;
        }
    }
    return result;
}

function buildGroups() {
    groups = groupImages(images);
}

function appendGroups(incoming) {
    const additions = groupImages(incoming);
    if (!additions.length) return groups.length;
    let changedFrom = groups.length;
    const last = groups[groups.length - 1];
    const first = additions[0];
    if (last && Math.abs(last.lastMs - first.start) <= gapHours * 3600 * 1000) {
        changedFrom -= 1;
        last.images.push(...first.images);
        last.start = Math.max(last.start, first.start);
        last.end = Math.min(last.end, first.end);
        last.lastMs = first.lastMs;
        additions.shift();
    }
    groups.push(...additions);
    return changedFrom;
}

function cellHtml(img, index) {
    const selected = selection.has(Number(img.id));
    const previewSrc = previewThumbUrl(img);
    return `<figure class="cell ${previewSrc ? '' : 'preview-pending'} ${selected ? 'sel' : ''}" data-id="${img.id}" data-idx="${index}" tabindex="-1" aria-selected="${selected ? 'true' : 'false'}" style="--ar:${aspect(img)}">`
        + `<img data-preview-src="${esc(previewSrc)}" ${previewSrc ? `data-src="${esc(previewSrc)}"` : ''} loading="lazy" decoding="async" fetchpriority="low" alt="${esc(img.filename || '')}">`
        + `<span class="c-placeholder-name">${esc(img.filename || '')}</span>`
        + `<button class="c-check" aria-label="Select photo" tabindex="-1">${icon('check')}</button>`
        + `<span class="c-idx">${index + 1}</span><span class="c-elo"><span class="elo-chip">${Math.round(Number(img.elo) || 0)}</span></span></figure>`;
}

function patchCells(imageIds = null) {
    const ids = Array.isArray(imageIds) ? imageIds.map(Number).filter((id) => id > 0) : [];
    const cells = ids.length
        ? ids.flatMap((id) => [...document.querySelectorAll(`#events-flow .cell[data-id="${id}"]`)])
        : [...document.querySelectorAll('#events-flow .cell[data-id]')];
    for (const cell of cells) {
        const selected = selection.has(Number(cell.dataset.id));
        cell.classList.toggle('sel', selected);
        cell.setAttribute('aria-selected', String(selected));
    }
}

function coverageDots(group) {
    const count = group.images.length;
    const covered = group.images.filter((img) => signals(img) >= SORTED_SIGNAL_MIN).length;
    const filled = count ? Math.round((covered / count) * 5) : 0;
    return Array.from({ length: 5 }, (_, i) => `<i class="${i < filled ? 'q' : ''}"></i>`).join('');
}

function patchCoverageDots() {
    buildGroups();
    groups.forEach((group, index) => {
        const dotHost = document.querySelector(`#events-flow .event-block[data-group="${index}"] .ev-dots`);
        if (dotHost) dotHost.innerHTML = coverageDots(group);
    });
}

function renderSkeleton() {
    document.getElementById('events-flow').innerHTML = '<div class="event-block">'
        + '<div class="event-head"><div class="skel" style="width:220px;height:18px"></div></div>'
        + '<div class="event-body"><div class="event-hero skel"></div><div class="event-tiles">'
        + Array.from({ length: 12 }, (_, i) => `<div class="cell skel-cell" style="--ar:${[1.4, .8, 1.8][i % 3]}"></div>`).join('')
        + '</div></div></div>';
}

function heroFor(group) {
    const ranked = [...group.images].sort((a, b) => (Number(b.elo) || 0) - (Number(a.elo) || 0));
    return ranked.find((image) => image.preview_ready !== false) || ranked[0];
}

function groupHtml(group, groupIndex) {
    const title = titleFor(group);
    const hero = heroFor(group);
    const heroSrc = previewThumbUrl(hero, 'md');
    const expanded = expandedEvents.has(group.id) || group.images.length <= 18;
    const visibleTiles = (expanded ? group.images : group.images.slice(0, 18)).filter((img) => Number(img.id) !== Number(hero.id));
    const hidden = Math.max(0, group.images.length - visibleTiles.length - 1);
    return `<article class="event-block" data-group="${groupIndex}">`
        + `<header class="event-head"><h2>${esc(title)}</h2><span class="ev-count">${fmt(group.images.length)} photos</span>`
        + `<span class="ev-dots" data-tip="Ranking coverage">${coverageDots(group)}</span><span class="ev-spacer"></span>`
        + `<button class="ev-menu-btn" data-menu="${groupIndex}" data-tip="Event actions" aria-label="Event actions">${icon('ellipsis')}</button></header>`
        + '<div class="event-body">'
        + `<figure class="event-hero ${heroSrc ? '' : 'preview-pending'}" data-id="${hero.id}"><img data-preview-src="${esc(heroSrc)}" ${heroSrc ? `data-src="${esc(heroSrc)}"` : ''} fetchpriority="low" alt="${esc(hero.filename || '')}"><figcaption class="hero-cap"><span>${esc(hero.filename || '')}</span><span>${Math.round(Number(hero.elo) || 0)}</span></figcaption></figure>`
        + `<div class="event-tiles">${visibleTiles.map((img) => cellHtml(img, imageIndexes.get(Number(img.id)) ?? 0)).join('')}`
        + `${hidden > 0 ? `<button class="ev-more" data-expand="${groupIndex}">+${fmt(hidden)} more</button>` : ''}</div></div></article>`;
}

function render() {
    if (!mounted) return;
    buildGroups();
    const flow = document.getElementById('events-flow');
    if (!groups.length && !loading) {
        flow.innerHTML = '<div class="grid-empty"><h3>No dated photos in this view.</h3><p>Add a source if your library is empty, or try another view.</p></div>'
            + '<div id="events-sentinel"></div><div class="grid-end" id="events-end" hidden>End of view</div>';
        document.getElementById('events-end').hidden = !done || images.length === 0;
        return;
    }
    flow.innerHTML = groups.map(groupHtml).join('')
        + '<div id="events-sentinel"></div><div class="grid-end" id="events-end" hidden>End of view</div>';
    document.getElementById('events-end').hidden = !done || images.length === 0;
    observeImages(flow, { reset: true });
}

function observeImages(root, { reset = false } = {}) {
    if (reset && imageObserver) imageObserver.disconnect();
    if (!imageObserver || reset) {
        imageObserver = new IntersectionObserver((entries) => {
            for (const entry of entries) {
                const img = entry.target;
                if (entry.isIntersecting && !img.src) img.src = img.dataset.src;
            }
        }, { root: document.getElementById('canvas'), rootMargin: '700px 0px' });
    }
    for (const img of root.querySelectorAll('img[data-src]')) {
        img.addEventListener('load', () => img.classList.add('ld'), { once: true });
        imageObserver.observe(img);
    }
}

function pendingPreviewIds() {
    return images
        .filter((image) => image && image.preview_ready === false)
        .map((image) => Number(image.id))
        .filter((id) => id > 0);
}

function loadSharpenedPreview(img, src) {
    if (!img || !src) return;
    img.addEventListener('load', () => img.classList.add('ld'), { once: true });
    img.dataset.previewSrc = src;
    img.dataset.src = src;
    img.src = src;
}

function sharpenPreview(image) {
    const id = Number(image?.id);
    const known = images.find((item) => Number(item?.id) === id);
    if (!id || !known || known.preview_ready) return false;
    Object.assign(known, image);
    const heroChanged = groups.some((group, groupIndex) => {
        if (!group.images.some((item) => Number(item.id) === id)) return false;
        const rendered = document.querySelector(`#events-flow .event-block[data-group="${groupIndex}"] .event-hero`);
        return rendered && Number(rendered.dataset.id) !== Number(heroFor(group)?.id);
    });
    if (heroChanged) return true;
    for (const cell of document.querySelectorAll(`#events-flow .cell[data-id="${id}"].preview-pending`)) {
        cell.classList.remove('preview-pending');
        loadSharpenedPreview(cell.querySelector('img[data-preview-src]'), previewThumbUrl(known));
    }
    for (const hero of document.querySelectorAll(`#events-flow .event-hero[data-id="${id}"].preview-pending`)) {
        hero.classList.remove('preview-pending');
        loadSharpenedPreview(hero.querySelector('img[data-preview-src]'), previewThumbUrl(known, 'md'));
    }
    return false;
}

async function refreshPendingPreviews() {
    const ids = pendingPreviewIds();
    if (!ids.length) return;
    const params = scopeParams({ limit: Math.min(ids.length, 5000), offset: 0, sort: 'date_taken' });
    params.set('ids', ids.join(','));
    const data = await getRankings(params).catch(() => null);
    if (!mounted || !Array.isArray(data?.images)) return;
    let rerender = false;
    for (const image of data.images) {
        if (image.preview_ready) rerender = sharpenPreview(image) || rerender;
    }
    if (rerender) {
        render();
        setupSentinel();
    }
}

function renderAppendedGroups(changedFrom) {
    if (!mounted) return;
    const flow = document.getElementById('events-flow');
    const sentinel = document.getElementById('events-sentinel');
    if (!sentinel) {
        render();
        return;
    }
    for (const article of flow.querySelectorAll('.event-block[data-group]')) {
        if (Number(article.dataset.group) < changedFrom) continue;
        for (const img of article.querySelectorAll('img[data-src]')) imageObserver?.unobserve(img);
        article.remove();
    }
    const fragment = document.createRange().createContextualFragment(
        groups.slice(changedFrom).map((group, index) => groupHtml(group, changedFrom + index)).join(''),
    );
    const added = [...fragment.querySelectorAll('.event-block')];
    sentinel.before(fragment);
    for (const article of added) observeImages(article);
    document.getElementById('events-end').hidden = !done || images.length === 0;
}

async function loadPage() {
    if (!mounted || loading || done) return;
    loading = true;
    const seq = generation;
    try {
        const data = await loadScopePage({ limit: PAGE_SIZE, offset, sort: 'date_taken' });
        if (seq !== generation) return;
        if (!data) {
            document.getElementById('events-flow').innerHTML = '<div class="load-error"><h4>Couldn\'t load events</h4><p>The archive did not respond.</p><button class="btn" id="events-retry">Try again</button></div>';
            document.getElementById('events-retry')?.addEventListener('click', loadPage);
            return;
        }
        const incoming = data.images || [];
        const firstPage = images.length === 0;
        incoming.forEach((img, index) => imageIndexes.set(Number(img.id), images.length + index));
        offset += incoming.length;
        done = incoming.length < PAGE_SIZE;
        images = images.concat(incoming);
        setImages(images);
        if (offset === incoming.length) setRankingsMeta({ visibleImages: data.visible_images, sortQuality: data.sort_quality });
        if (firstPage) {
            render();
            setupSentinel();
        } else {
            renderAppendedGroups(appendGroups(incoming));
            setupSentinel();
        }
        scheduleThumbnailPoll();
    } catch {
        if (seq !== generation) return;
        document.getElementById('events-flow').innerHTML = '<div class="load-error"><h4>Couldn\'t load events</h4><p>The archive did not respond.</p><button class="btn" id="events-retry">Try again</button></div>';
        document.getElementById('events-retry')?.addEventListener('click', loadPage);
    } finally {
        if (seq === generation) loading = false;
    }
}

function setupSentinel() {
    if (observer) observer.disconnect();
    const sentinel = document.getElementById('events-sentinel');
    if (!sentinel) return;
    observer = new IntersectionObserver((entries) => {
        if (entries.some((entry) => entry.isIntersecting)) loadPage();
    }, { root: document.getElementById('canvas'), rootMargin: '900px 0px' });
    observer.observe(sentinel);
}

function closeMenu() {
    if (menu) {
        releaseFocus(menu);
        menu.remove();
    }
    menu = null;
}

function openMenu(button, groupIndex) {
    closeMenu();
    const group = groups[groupIndex];
    if (!group) return;
    const ids = group.images.map((img) => Number(img.id)).filter((id) => id > 0);
    menu = document.createElement('div');
    menu.className = 'pop-menu on event-menu grid-pop-menu';
    menu.setAttribute('role', 'menu');
    menu.innerHTML = `<button data-act="collection" role="menuitem">${icon('folder-plus')} Make collection from event</button>`
        + `<button data-act="refine" role="menuitem">${icon('zap')} Open in Refine</button>`
        + `<button data-act="select" role="menuitem">${icon('check')} Select all in event</button>`;
    document.body.appendChild(menu);
    const rect = button.getBoundingClientRect();
    menu.style.left = `${Math.min(window.innerWidth - 230, rect.right - 210)}px`;
    menu.style.top = `${rect.bottom + 6}px`;
    trapFocus(menu, menu.querySelector('button'));
    menu.addEventListener('keydown', (event) => {
        if (event.key === 'Escape') {
            event.preventDefault();
            closeMenu();
            button.focus({ preventScroll: true });
            return;
        }
        if (event.key !== 'ArrowDown' && event.key !== 'ArrowUp') return;
        event.preventDefault();
        const buttons = [...menu.querySelectorAll('button')];
        const index = Math.max(0, buttons.indexOf(document.activeElement));
        buttons[(index + (event.key === 'ArrowDown' ? 1 : -1) + buttons.length) % buttons.length].focus();
    });
    menu.addEventListener('click', async (event) => {
        const action = event.target.closest('button')?.dataset.act;
        if (!action) return;
        closeMenu();
        if (action === 'collection') {
            const result = await createCollection(titleFor(group), ids);
            if (result && result.ok) {
                const coll = result.collection || {};
                showToast('Collection created from event', {
                    undo: coll.id ? async () => {
                        const removed = await removeFromCollection(coll.id, ids);
                        if (removed?.ok) showToast('Event photos removed from collection');
                        else {
                            showToast("Couldn't undo collection change");
                            emit('collections:refresh');
                        }
                    } : null,
                });
            } else showToast("Couldn't create collection");
        } else if (action === 'refine') {
            showToast('Opening Refine for this event.');
            emit('refine:open');
        } else if (action === 'select') {
            ids.forEach((id) => selection.add(id));
            selectionChanged(ids);
            patchCells(ids);
        }
    });
}

function resetData() {
    stopThumbnailPoll();
    generation += 1;
    offset = 0;
    done = false;
    loading = false;
    images = [];
    groups = [];
    imageIndexes.clear();
    expandedEvents.clear();
    setImages([]);
    setRankingsMeta({ visibleImages: 0, sortQuality: null });
}

function reload({ skeleton = true } = {}) {
    if (!mounted) return;
    resetData();
    if (skeleton) renderSkeleton();
    loadPage();
}

async function revalidate({ refreshCoverage = false } = {}) {
    const seq = generation;
    try {
        const pageSize = refreshCoverage ? Math.max(PAGE_SIZE, images.length) : PAGE_SIZE;
        const data = await loadScopePage({ limit: pageSize, offset: 0, sort: 'date_taken' });
        if (!mounted || seq !== generation || !data) return;
        const incoming = data.images || [];
        const changed = Number(data.visible_images) !== viewState.visibleImages
            || incoming.length !== Math.min(images.length, pageSize)
            || incoming.some((image, i) => (
                Number(image.id) !== Number(images[i]?.id)
                || captureMs(image) !== captureMs(images[i])
            ));
        if (!changed) {
            if (refreshCoverage) {
                incoming.forEach((image, index) => { images[index] = image; });
                setImages(images);
                setRankingsMeta({ visibleImages: data.visible_images, sortQuality: data.sort_quality });
                patchCoverageDots();
            }
            return;
        }
        resetData();
        images = incoming;
        incoming.forEach((image, i) => imageIndexes.set(Number(image.id), i));
        offset = incoming.length;
        done = incoming.length < PAGE_SIZE;
        setImages(images);
        setRankingsMeta({ visibleImages: data.visible_images, sortQuality: data.sort_quality });
        render();
        setupSentinel();
    } catch {
        // Keep the last successful event view visible while the refresh is unavailable.
    }
}

export function initEvents() {
    if (initialized) return;
    initialized = true;
    document.getElementById('events-flow').addEventListener('click', (event) => {
        const menuButton = event.target.closest('[data-menu]');
        if (menuButton) {
            openMenu(menuButton, Number(menuButton.dataset.menu));
            return;
        }
        const expand = event.target.closest('[data-expand]');
        if (expand) {
            const group = groups[Number(expand.dataset.expand)];
            if (group) expandedEvents.add(group.id);
            render();
            return;
        }
        const check = event.target.closest('.c-check');
        if (check) {
            const cell = check.closest('.cell[data-id]');
            if (cell) toggleSelection(cell.dataset.id, cell.dataset.idx, { range: event.shiftKey });
            return;
        }
        const cell = event.target.closest('.cell[data-id], .event-hero[data-id]');
        if (cell) emit('loupe:open', { id: Number(cell.dataset.id), index: images.findIndex((img) => Number(img.id) === Number(cell.dataset.id)) });
    });
    document.addEventListener('pointerdown', (event) => {
        if (menu && !menu.contains(event.target) && !event.target.closest('.ev-menu-btn')) closeMenu();
    });
    on('scope', () => {
        resetData();
        if (mounted) reload();
    });
    on('selection', ({ imageIds } = {}) => patchCells(imageIds));
    on('flags', ({ imageIds } = {}) => {
        patchCells(imageIds);
        if (mounted) revalidate({ refreshCoverage: true });
    });
}

export function mountEvents() {
    mounted = true;
    document.getElementById('view-events').classList.add('active');
    if (images.length) {
        observeImages(document.getElementById('events-flow'));
        setupSentinel();
        scheduleThumbnailPoll();
        requestAnimationFrame(() => document.getElementById('canvas').scrollTo({ top: savedScrollTop, behavior: 'auto' }));
        revalidate();
    } else reload();
}

export function unmountEvents() {
    savedScrollTop = document.getElementById('canvas').scrollTop;
    mounted = false;
    generation += 1;
    stopThumbnailPoll();
    closeMenu();
    if (observer) observer.disconnect();
    if (imageObserver) imageObserver.disconnect();
    observer = null;
    imageObserver = null;
    document.getElementById('view-events').classList.remove('active');
}

export function setEventGap(hours) {
    gapHours = [3, 6, 24].includes(Number(hours)) ? Number(hours) : 6;
    localStorage.setItem(GAP_KEY, String(gapHours));
    render();
}

export function eventGap() {
    return gapHours;
}
